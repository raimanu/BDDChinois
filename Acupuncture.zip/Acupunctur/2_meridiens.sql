INSERT INTO meridien (organe)
VALUES ('cœur'),
       ('poumon'),
       ('foie'),
       ('reins'),
       ('vésicule biliaire'),
       ('rate'),
       ('utérus'),
       ('gros intestin'),
       ('petit intestin'),
       ('poumons'),
       ('foie (ou poumons)'),
       ('estomac');

INSERT INTO meridien (nom_meridien)
VALUES ('six fu'),
       ('zhèngzhòng (centre droit 正中)');

select * from meridien;

